    `Has Been Modified`
        when something has changed in the `Scene`
    `Item Selected`
        when `Node` or `Edge` is selected
    `Items Deselected`
        when deselect everything appears
    `Drag Enter`
        when something is Dragged onto the `Scene`. Here we do allow or deny the drag
    `Drop`
        when we Drop something into the `Scene`
