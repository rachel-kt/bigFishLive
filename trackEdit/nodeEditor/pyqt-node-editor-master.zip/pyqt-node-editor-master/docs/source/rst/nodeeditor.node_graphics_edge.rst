.. py:currentmodule:: nodeeditor.node_graphics_edge

:py:mod:`node\_graphics\_edge` Module
======================================

.. automodule:: nodeeditor.node_graphics_edge


`QDMGraphicsEdge` class
------------------------------

.. autoclass:: QDMGraphicsEdge
    :members:
    :undoc-members:
    :show-inheritance:
