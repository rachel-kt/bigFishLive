.. py:currentmodule:: nodeeditor.node_edge_rerouting

:py:mod:`node\_edge\_rerouting` Module
=======================================

.. automodule:: nodeeditor.node_edge_rerouting
    :members:
    :undoc-members:
    :show-inheritance:
