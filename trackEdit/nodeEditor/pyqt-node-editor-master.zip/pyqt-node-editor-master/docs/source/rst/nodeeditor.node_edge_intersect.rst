.. py:currentmodule:: nodeeditor.node_edge_intersect

:py:mod:`node\_edge\_intersect` Module
=======================================

.. automodule:: nodeeditor.node_edge_intersect
    :members:
    :undoc-members:
    :show-inheritance:
