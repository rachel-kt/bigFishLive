.. py:currentmodule:: nodeeditor.node_scene_history

:py:mod:`node\_scene\_history` Module
======================================

.. automodule:: nodeeditor.node_scene_history

Events
------

.. include:: events_scene_history.rst

SceneHistory Class
------------------

.. autoclass:: SceneHistory
    :members:
    :undoc-members:
    :show-inheritance:
